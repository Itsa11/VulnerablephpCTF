<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

  <title>Secure Coding | Secured</title>
</head>

<body>
  <div class="container py-2">
    <div class="jumbotron">
      <h1>Login</h1>
      <form method="POST" action="index.php">
        <div class="form-group">
          <label>Username</label>
          <input type="text" class="form-control" name="username" placeholder="Enter Username">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" class="form-control" name="password" placeholder="Enter Password">
        </div>
        <div class="form-group">
          <button class="btn btn-success" type="submit">Login</button>
        </div>
      </form>
    </div>
  </div>
  <?php
  include "connection.php";
  include "sanitize.php";
  session_start();

  if (isset($_POST['username']) && isset($_POST['password'])) {

    # to protect against SQLi 
    # Creating prepared statement and binding uname and password to the statement
    $auth_query = $connection->prepare("SELECT id FROM users WHERE username = ? AND password = ?");
    $auth_query->bind_param("ss", $uname, $password);

    # to protect against XSS 
    $uname = sanitize_input($_POST['username']);
    $password = sanitize_input($_POST['password']);

    # executing query and storing run status
    $auth_query->execute();

    $auth_query->store_result();
    $num_rows = $auth_query->num_rows;

    # binding result to $id
    $auth_query->bind_result($id);
    $auth_query->fetch();
    $auth_query->close();

    if ($num_rows > 0) {
      echo 'Login Successfull';
      $_SESSION["id"] = $id;
      header("Location: profile.php?id=" . $_SESSION["id"]);
    }
  }
  ?>

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>